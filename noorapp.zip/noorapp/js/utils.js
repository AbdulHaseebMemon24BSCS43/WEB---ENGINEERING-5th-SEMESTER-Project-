/* ═══════════════════════════════════════════════════
   NoorApp — Utilities
   ═══════════════════════════════════════════════════ */

/**
 * Returns the HTML for an animated loading indicator.
 */
function loader() {
  return `<div class="loader">
    <div class="loader-dot"></div>
    <div class="loader-dot"></div>
    <div class="loader-dot"></div>
    <span>Loading…</span>
  </div>`;
}

/**
 * Navigation — show a section by id, hiding others.
 * Also lazy-loads section data on first visit.
 */
function showSection(id) {
  document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));

  document.getElementById('section-' + id).classList.add('active');

  // Highlight matching nav button
  document.querySelectorAll('.nav-btn').forEach(b => {
    if (b.textContent.toLowerCase().includes(id.slice(0, 4))) {
      b.classList.add('active');
    }
  });

  // Lazy-load each section
  if (id === 'quran'    && surahList.length === 0) initQuran();
  if (id === 'prayer')   loadPrayerTimes();
  if (id === 'dua')      renderDua('morning');
  if (id === 'tasbeeh')  renderTasbeeh();
  if (id === 'hadith')   loadHadith();
  if (id === 'calendar') loadCalendar();
}

// Activate Home nav on DOMContentLoaded
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.nav-btn')[0].classList.add('active');
});
