/* ═══════════════════════════════════════════════════
   NoorApp — Quran Reader (alquran.cloud API)
   ═══════════════════════════════════════════════════ */

let currentAudio = null;
let searchTimer;

async function initQuran() {
  try {
    const res = await fetch('https://api.alquran.cloud/v1/surah');
    const data = await res.json();
    surahList = data.data;

    const sel = document.getElementById('surah-select');
    surahList.forEach(s => {
      const o = document.createElement('option');
      o.value = s.number;
      o.textContent = `${s.number}. ${s.englishName} — ${s.name}`;
      sel.appendChild(o);
    });
  } catch (e) {
    console.error('Failed to load surah list:', e);
  }

  if (firstQuranVisit) {
    firstQuranVisit = false;
    const randomMsg = QURAN_MOTIVATION_UR[Math.floor(Math.random() * QURAN_MOTIVATION_UR.length)];
    document.getElementById('quran-content').innerHTML = `
      <div style="background:linear-gradient(135deg,rgba(74,222,128,0.1),rgba(212,168,83,0.1));border:1px solid var(--green);border-radius:12px;padding:2rem;text-align:center;margin-bottom:2rem;">
        <div style="font-size:3rem;margin-bottom:1rem;">📖</div>
        <div style="font-family:var(--arabic);font-size:1.4rem;color:var(--gold);margin-bottom:1rem;">قرآن کریم</div>
        <div style="color:var(--text);font-size:1.1rem;line-height:1.8;max-width:600px;margin:0 auto 1.5rem;">${randomMsg}</div>
        <button class="btn-primary" onclick="loadSurah()">اب شروع کریں</button>
      </div>
    `;
    return;
  }

  const sel = document.getElementById('surah-select');
  if (surahList.length > 0) {
    sel.value = '1';
    loadSurah();
  } else {
    document.getElementById('quran-content').innerHTML = `
      <div class="error-box">Could not load Surah list. Please check your connection and try again.</div>
    `;
  }
}

async function loadSurah(num) {
  num = num || parseInt(document.getElementById('surah-select')?.value) || 1;
  currentSurah = num;
  document.getElementById('quran-search').value = '';
  const el = document.getElementById('quran-content');
  el.innerHTML = loader();

  try {
    const lang = currentLang;
    const [arRes, transRes] = await Promise.all([
      fetch(`https://api.alquran.cloud/v1/surah/${num}`),
      fetch(lang === 'ur'
        ? `https://api.alquran.cloud/v1/surah/${num}/ur.ahmedali`
        : `https://api.alquran.cloud/v1/surah/${num}/en.asad`)
    ]);

    if (!arRes.ok) throw new Error('Failed to fetch Arabic');
    const arData = await arRes.json();

    let transMap = {};
    if (transRes.ok) {
      const transData = await transRes.json();
      if (transData.data?.ayahs) {
        transData.data.ayahs.forEach(a => { transMap[a.numberInSurah] = a.text; });
      }
    }

    renderSurah(arData.data, transMap, lang);
  } catch (e) {
    console.error('Failed to load Surah:', e);
    el.innerHTML = `<div class="error-box">
      Failed to load Surah. Please check your internet connection and try again.
      <br><br>
      <button class="btn-primary" onclick="loadSurah(${num})">Retry</button>
    </div>`;
  }
}

function renderSurah(arData, transMap, lang) {
  let html = `
    <div class="surah-header">
      <div class="surah-name-ar">${arData.name}</div>
      <div class="surah-meta">${arData.numberOfAyahs} verses · ${arData.revelationType}</div>
    </div>
  `;

  if (arData.number !== 9) {
    html += `<div style="text-align:center;font-family:var(--arabic);font-size:2rem;color:var(--gold);margin-bottom:1.5rem;letter-spacing:0.04em;direction:rtl;">بِسۡمِ ٱللَّهِ ٱلرَّحۡمَٰنِ ٱلرَّحِيمِ</div>`;
  }

  arData.ayahs.forEach(ayah => {
    const translation = transMap[ayah.numberInSurah] || '';
    html += `
      <div class="ayah-card">
        <div class="ayah-arabic">${ayah.text}</div>
        ${showTranslation && translation ? `<div class="ayah-translation">${translation}</div>` : ''}
        <div class="ayah-footer">
          <div class="ayah-number">${ayah.numberInSurah}</div>
          <div style="font-family:var(--mono);font-size:0.78rem;color:var(--text-muted);">${arData.englishName} ${ayah.numberInSurah}:${arData.number}</div>
          <button class="audio-btn" onclick="playAyahAudio(${ayah.number})">▶ Play</button>
        </div>
      </div>
    `;
  });

  document.getElementById('quran-content').innerHTML = html;
}

function toggleTranslation() {
  showTranslation = !showTranslation;
  const btn = document.getElementById('show-translation-btn');
  btn.textContent = showTranslation ? 'Translation ✓' : 'Translation ✗';
  btn.classList.toggle('active-btn', showTranslation);
  const sel = document.getElementById('surah-select');
  if (sel?.value) loadSurah(parseInt(sel.value));
}

function changeLanguage() {
  currentLang = document.getElementById('lang-select').value;
  const sel = document.getElementById('surah-select');
  if (sel?.value) loadSurah(parseInt(sel.value));
}

function prevSurah() {
  if (currentSurah > 1) {
    currentSurah--;
    document.getElementById('surah-select').value = currentSurah;
    loadSurah(currentSurah);
  }
}

function nextSurah() {
  if (currentSurah < 114) {
    currentSurah++;
    document.getElementById('surah-select').value = currentSurah;
    loadSurah(currentSurah);
  }
}

async function randomAyah() {
  const surah = Math.floor(Math.random() * 114) + 1;
  currentSurah = surah;
  document.getElementById('surah-select').value = surah;
  await loadSurah(surah);
}

function searchQuran() {
  clearTimeout(searchTimer);
  const q = document.getElementById('quran-search').value.trim().toLowerCase();
  if (!q) { loadSurah(currentSurah); return; }

  searchTimer = setTimeout(async () => {
    document.getElementById('quran-content').innerHTML = loader();
    try {
      const res = await fetch(`https://api.alquran.cloud/v1/search/${encodeURIComponent(q)}/all/en.asad`);
      if (!res.ok) throw new Error('Search failed');
      const data = await res.json();

      if (!data.data?.matches?.length) {
        document.getElementById('quran-content').innerHTML =
          '<div style="color:var(--text-muted);padding:2rem;text-align:center;">No results found. Try a different search term.</div>';
        return;
      }

      let html = `<div style="color:var(--text-muted);font-size:1rem;margin-bottom:1rem;">${data.data.count} result(s) for "${q}"</div>`;
      data.data.matches.slice(0, 15).forEach(m => {
        html += `
          <div class="ayah-card">
            <div class="ayah-arabic" style="font-size:1.4rem;">${m.text}</div>
            <div class="ayah-translation">${m.text}</div>
            <div class="ayah-meta" style="margin-top:0.6rem;">${m.surah.englishName} — Ayah ${m.numberInSurah}</div>
          </div>
        `;
      });
      document.getElementById('quran-content').innerHTML = html;
    } catch (e) {
      console.error('Search error:', e);
      document.getElementById('quran-content').innerHTML =
        '<div class="error-box">Search failed. Please check your internet connection and try again.</div>';
    }
  }, 600);
}

function playAyahAudio(ayahNumber) {
  if (currentAudio) { currentAudio.pause(); currentAudio = null; }
  const padded = String(ayahNumber).padStart(6, '0');
  const url = `https://cdn.islamic.network/quran/audio/128/ar.alafasy/${padded}.mp3`;
  currentAudio = new Audio(url);
  currentAudio.play().catch(() => {});
}

// Ayah of the Day (Home section)
(async function loadAyahOfDay() {
  const el = document.getElementById('ayah-of-day');
  if (!el) return;
  try {
    const ayahNum = Math.floor(Math.random() * 6236) + 1;
    const [arRes, enRes] = await Promise.all([
      fetch(`https://api.alquran.cloud/v1/ayah/${ayahNum}`),
      fetch(`https://api.alquran.cloud/v1/ayah/${ayahNum}/en.asad`)
    ]);
    if (!arRes.ok || !enRes.ok) throw new Error('Failed to fetch');
    const ar = await arRes.json();
    const en = await enRes.json();
    if (ar.data && en.data) {
      el.innerHTML = `
        <div style="margin-bottom:1.5rem;font-family:var(--arabic);font-size:1.6rem;color:var(--text);">Ayah of the Moment</div>
        <div class="ayah-card" style="border-color:var(--gold-dim);padding:2rem;">
          <div class="ayah-arabic" style="font-size:1.8rem;">${ar.data.text}</div>
          <div class="ayah-translation" style="font-size:1.15rem;">${en.data.text}</div>
          <div class="ayah-meta" style="margin-top:0.8rem;font-size:0.9rem;">${ar.data.surah.englishName} (${ar.data.surah.name}) — ${ar.data.numberInSurah}:${ar.data.surah.number}</div>
        </div>
      `;
    }
  } catch (e) {
    console.error('Ayah of day error:', e);
    el.innerHTML = '';
  }
})();
