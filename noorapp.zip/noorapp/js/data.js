/* ═══════════════════════════════════════════════════
   NoorApp — State & Data
   ═══════════════════════════════════════════════════ */

// ── APP STATE ──────────────────────────────────────
let currentSurah = 1;
let showTranslation = true;
let currentLang = 'en';
let hadithLang = 'en';
let tasbeehCount = 0;
let tasbeehSets = 0;
let tasbeehTarget = 33;
let activeTasbeehIndex = 0;
let surahList = [];
let firstQuranVisit = true;

// ── TASBEEH DATA ───────────────────────────────────
const TASBEEH_PHRASES = [
  {
    ar: 'سُبْحَانَ اللَّهِ',
    label: 'Subhanallah',
    full: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ ، سُبْحَانَ اللَّهِ الْعَظِيمِ',
    meaning: '"Glory be to Allah and His is the praise, Glory be to Allah the Most Great"'
  },
  {
    ar: 'الْحَمْدُ لِلَّهِ',
    label: 'Alhamdulillah',
    full: 'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ',
    meaning: '"All praise be to Allah, Lord of all the worlds"'
  },
  {
    ar: 'اللَّهُ أَكْبَرُ',
    label: 'Allahu Akbar',
    full: 'اللَّهُ أَكْبَرُ كَبِيرًا ، وَالْحَمْدُ لِلَّهِ كَثِيرًا',
    meaning: '"Allah is the Greatest, and much praise be to Allah"'
  },
  {
    ar: 'لَا إِلَٰهَ إِلَّا اللَّهُ',
    label: 'La ilaha',
    full: 'لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ',
    meaning: '"There is no god but Allah, alone, without partner"'
  },
  {
    ar: 'أَسْتَغْفِرُ اللَّهَ',
    label: 'Astaghfirullah',
    full: 'أَسْتَغْفِرُ اللَّهَ الْعَظِيمَ وَأَتُوبُ إِلَيْهِ',
    meaning: '"I seek forgiveness from Allah the Magnificent and repent to Him"'
  },
];

// ── DUA DATA ───────────────────────────────────────
const DUA_DATA = {
  morning: [
    {
      name: 'Dua upon waking',
      ar: 'الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ',
      trans: 'Al-Bukhari 6325 — "All praise is for Allah who gave us life after having taken it from us and unto Him is the resurrection."',
      trl: "Alhamdu lillahil-ladhi ahyana ba'da ma amatana wa ilayhin-nushur"
    },
    {
      name: 'Morning Remembrance',
      ar: 'أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ وَالْحَمْدُ لِلَّهِ لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ',
      trans: 'Abu Dawud 5084 — "We have reached the morning and at this very time unto Allah belongs all sovereignty, and all praise is for Allah."',
      trl: 'Asbahna wa asbahal-mulku lillah wal-hamdu lillah la ilaha illallahu wahdahu la sharika lah'
    },
    {
      name: 'Protection in the morning',
      ar: 'اللَّهُمَّ بِكَ أَصْبَحْنَا ، وَبِكَ أَمْسَيْنَا ، وَبِكَ نَحْيَا ، وَبِكَ نَمُوتُ ، وَإِلَيْكَ النُّشُورُ',
      trans: 'Tirmidhi 3391 — "O Allah, by Your leave we have reached the morning and by Your leave we have reached the evening, by Your leave we live and die and unto You is the resurrection."',
      trl: 'Allahumma bika asbahna wa bika amsayna wa bika nahya wa bika namutu wa ilaykan-nushur'
    },
  ],
  evening: [
    {
      name: 'Evening remembrance',
      ar: 'أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ وَالْحَمْدُ لِلَّهِ لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ',
      trans: 'Muslim 2723 — "We have reached the evening and at this very time unto Allah belongs all sovereignty, and all praise is for Allah."',
      trl: 'Amsayna wa amsal-mulku lillah wal-hamdu lillah la ilaha illallahu wahdahu la sharika lah'
    },
    {
      name: 'Evening protection',
      ar: 'اللَّهُمَّ مَا أَمْسَى بِي مِنْ نِعْمَةٍ أَوْ بِأَحَدٍ مِنْ خَلْقِكَ فَمِنْكَ وَحْدَكَ لَا شَرِيكَ لَكَ فَلَكَ الْحَمْدُ وَلَكَ الشُّكْرُ',
      trans: "Abu Dawud 5073 — \"O Allah, whatever blessing I or any of Your creation have reached the evening with, is from You alone, without partner, so for You is all praise and unto You all thanks.\"",
      trl: "Allahumma ma amsa bi min ni'matin aw bi ahadin min khalqika faminka wahdaka la sharika laka falakal-hamdu wa lakash-shukr"
    },
  ],
  sleep: [
    {
      name: 'Before sleeping',
      ar: 'بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا',
      trans: 'Bukhari 6312 — "In Your name O Allah, I die and I live."',
      trl: 'Bismika Allahumma amutu wa ahya'
    },
    {
      name: 'Protection before sleep',
      ar: 'اللَّهُمَّ قِنِي عَذَابَكَ يَوْمَ تَبْعَثُ عِبَادَكَ',
      trans: "Abu Dawud 5045 — \"O Allah protect me from Your punishment on the day that You resurrect Your servants.\"",
      trl: "Allahumma qini adhabaka yawma tab'athu ibadak"
    },
  ],
  food: [
    {
      name: 'Before eating',
      ar: 'بِسْمِ اللَّهِ',
      trans: 'Bukhari 5376 — "In the name of Allah." Say this before starting every meal.',
      trl: 'Bismillah'
    },
    {
      name: 'After eating',
      ar: 'الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنَا وَسَقَانَا وَجَعَلَنَا مِنَ الْمُسْلِمِينَ',
      trans: 'Abu Dawud 3850 — "All praise is for Allah who has given us food and drink and who has made us Muslims."',
      trl: 'Alhamdu lillahil-ladhi at\'amana wa saqana wa ja\'alana minal-muslimin'
    },
  ],
  travel: [
    {
      name: 'When beginning a journey',
      ar: 'سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ وَإِنَّا إِلَى رَبِّنَا لَمُنْقَلِبُونَ',
      trans: 'Muslim 1342 — "Glory unto Him Who created this transportation, for us, though we were unable to create it on our own. And unto our Lord we shall return."',
      trl: 'Subhanalladhi sakhkhara lana hadha wa ma kunna lahu muqrinina wa inna ila rabbina lamunqalibun'
    },
  ],
};

// ── ISLAMIC EVENTS ─────────────────────────────────
const ISLAMIC_EVENTS = [
  { name: 'Ramadan begins',       hijri: '1 Ramadan 1447',       est: '~March 2026' },
  { name: 'Laylatul Qadr',        hijri: '27 Ramadan 1447',      est: '~March 2026' },
  { name: 'Eid ul-Fitr',          hijri: '1 Shawwal 1447',       est: '~April 2026' },
  { name: 'Eid ul-Adha',          hijri: '10 Dhul Hijjah 1447',  est: '~June 2026'  },
  { name: 'Day of Arafah',        hijri: '9 Dhul Hijjah 1447',   est: '~June 2026'  },
  { name: 'Islamic New Year',     hijri: '1 Muharram 1448',      est: '~July 2026'  },
  { name: 'Ashura',               hijri: '10 Muharram 1448',     est: '~July 2026'  },
  { name: 'Mawlid an-Nabi ﷺ',    hijri: "12 Rabi' al-Awwal 1448", est: '~Sep 2026' },
];

// ── QURAN MOTIVATIONAL MESSAGES (Urdu) ────────────
const QURAN_MOTIVATION_UR = [
  "قرآن پڑھنا اللّٰہ تعالیٰ سے بات کرنا ہے۔ جب آپ قرآن پڑھتے ہیں تو اللّٰہ آپ سے بات کرتا ہے۔",
  "قرآن اللّٰہ کی آخری کتاب ہے۔ یہ ہمارے لیے رہنما ہے اور ہمیں سیدھی راہ دکھاتی ہے۔",
  "جو شخص قرآن پڑھتا اور اس پر عمل کرتا ہے، اللّٰہ اسے جنت میں داخل کرے گا۔",
  "قرآن پڑھنے سے دل نورانی ہو جاتا ہے اور روح کو سکون ملتا ہے۔",
  "اللّٰہ تعالیٰ فرماتا ہے: 'ہم نے قرآن کو ذکر کے لیے آسان کیا ہے۔ کیا کوئی ذکر کرنے والا ہے؟'",
  "قرآن پڑھنا ہر مسلمان کی ذمہ داری ہے۔ یہ ہماری زندگی کا رہنما ہے۔",
  "جس دن میں نے پہلی بار قرآن پڑھا، میری زندگی بدل گئی۔ آپ بھی اس کتاب کی برکت محسوس کریں گے۔",
  "قرآن کی ہر آیت اللّٰہ کی نشانی ہے۔ اسے پڑھیں اور اس سے نصیحت حاصل کریں۔"
];

// ── FALLBACK HADITHS ───────────────────────────────
const FALLBACK_HADITHS = [
  {
    text: "The best of you are those who learn the Quran and teach it.",
    urdu: "تم میں سے بہترین وہ ہیں جو قرآن سیکھتے ہیں اور سکھاتے ہیں۔",
    source: "Sahih al-Bukhari 5027"
  },
  {
    text: "Indeed, actions are judged by intentions, and every person will get the reward according to what he has intended.",
    urdu: "بے شک اعمال نیتوں کے مطابق پرکھے جاتے ہیں، اور ہر شخص کو اس کے ارادے کے مطابق اجر ملے گا۔",
    source: "Sahih al-Bukhari 1"
  },
  {
    text: "None of you will have faith till he wishes for his Muslim brother what he likes for himself.",
    urdu: "تم میں سے کوئی ایمان نہیں رکھتا جب تک کہ وہ اپنے مسلم بھائی کے لیے وہ نہ چاہے جو وہ اپنے لیے چاہتا ہے۔",
    source: "Sahih al-Bukhari 13"
  },
  {
    text: "The strong man is not the one who overcomes the people by his strength, but the strong man is the one who controls himself while in anger.",
    urdu: "زورور شخص وہ نہیں جو لوگوں کو اپنی طاقت سے زیر کرے، بلکہ زورور شخص وہ ہے جو غصے میں اپنے آپ پر قابو رکھے۔",
    source: "Sahih al-Bukhari 6114"
  },
  {
    text: "Make things easy and do not make them difficult, cheer the people up by conveying glad tidings to them and do not repulse them.",
    urdu: "آسان بناؤ اور مشکل نہ بناؤ، لوگوں کو خوشخوشی کی خبریں دے کر خوش کرو اور انہیں دور نہ کرو۔",
    source: "Sahih al-Bukhari 69"
  },
  {
    text: "He who does not thank people, does not thank Allah.",
    urdu: "جو لوگوں کا شکر نہیں کرتا وہ اللہ کا شکر نہیں کرتا۔",
    source: "Sunan Abu Dawud 4811"
  },
  {
    text: "Smiling at your brother is charity (Sadaqah).",
    urdu: "اپنے بھائی پر مسکرانا صدقہ ہے۔",
    source: "Jami at-Tirmidhi 1956"
  },
];
