/* ═══════════════════════════════════════════════════
   NoorApp — Prayer Times (AlAdhan API)
   ═══════════════════════════════════════════════════ */

const PRAYER_ARABIC = {
  Fajr:    'الفجر',
  Dhuhr:   'الظهر',
  Asr:     'العصر',
  Maghrib: 'المغرب',
  Isha:    'العشاء',
  Sunrise: 'الشروق'
};

/**
 * Fetch prayer times for a city and render them.
 * Called by the Prayer Times section and the home strip auto-loader.
 */
async function loadPrayerTimes(city) {
  city = city || document.getElementById('city-input')?.value || 'Karachi';
  const method = document.getElementById('method-select')?.value || '1';
  const el = document.getElementById('prayer-content');
  if (el) el.innerHTML = loader();

  try {
    const today = new Date();
    const d = today.getDate(), m = today.getMonth() + 1, y = today.getFullYear();
    const url = `https://api.aladhan.com/v1/timingsByCity/${d}-${m}-${y}?city=${encodeURIComponent(city)}&country=&method=${method}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error('API error');
    const data = await res.json();
    if (data.code !== 200) throw new Error(data.status || 'Failed to get prayer times');

    renderPrayerTimes(data.data, city);
    renderHomePrayerStrip(data.data.timings);
  } catch (e) {
    console.error('Prayer times error:', e);
    if (el) el.innerHTML = `<div class="error-box">
      Could not load prayer times for "${city}". Please check your internet connection and try another city name.
      <br><br>
      <button class="btn-primary" onclick="loadPrayerTimes()">Retry</button>
    </div>`;
  }
}

function renderPrayerTimes(data, city) {
  const timings = data.timings;
  const hijri = data.date?.hijri;
  const prayers = ['Fajr', 'Sunrise', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
  const now = new Date();
  const nowMin = now.getHours() * 60 + now.getMinutes();

  let currentPrayer = null;
  prayers.forEach(p => {
    const [h, min] = timings[p].split(':').map(Number);
    if (nowMin >= h * 60 + min) currentPrayer = p;
  });

  let html = `
    <div class="hijri-box" style="margin-bottom:1.5rem;">
      <div style="font-family:var(--mono);font-size:0.82rem;color:var(--text-muted);">📍 ${city}</div>
      ${hijri ? `<div class="hijri-date">${hijri.day} ${hijri.month.en} ${hijri.year} AH</div>` : ''}
      <div class="gregorian-date">${now.toLocaleDateString('en-GB', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</div>
    </div>
    <div class="prayer-grid">
  `;

  prayers.forEach(p => {
    const isCur = p === currentPrayer;
    html += `
      <div class="prayer-card ${isCur ? 'current-prayer' : ''}">
        <div class="pc-name">${p}</div>
        <div class="pc-time">${timings[p]}</div>
        <div class="pc-arabic">${PRAYER_ARABIC[p] || ''}</div>
        ${isCur ? '<div style="font-size:0.75rem;color:var(--green);margin-top:4px;font-family:var(--mono);">▶ Current</div>' : ''}
      </div>
    `;
  });
  html += '</div>';

  if (timings.Midnight) {
    html += `
      <div class="card" style="display:inline-flex;gap:2rem;margin-top:0.5rem;">
        <div>
          <span style="font-family:var(--mono);font-size:0.78rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.1em;">Midnight</span>
          <br><span style="font-family:var(--mono);">${timings.Midnight}</span>
        </div>
        <div>
          <span style="font-family:var(--mono);font-size:0.78rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.1em;">Last Third</span>
          <br><span style="font-family:var(--mono);">${timings.Lastthird || '—'}</span>
        </div>
      </div>
    `;
  }

  document.getElementById('prayer-content').innerHTML = html;
}

function renderHomePrayerStrip(timings) {
  const prayers = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
  const now = new Date();
  const nowMin = now.getHours() * 60 + now.getMinutes();
  let currentPrayer = null;

  prayers.forEach(p => {
    const [h, m] = timings[p].split(':').map(Number);
    if (nowMin >= h * 60 + m) currentPrayer = p;
  });

  const strip = document.getElementById('home-prayer-strip');
  if (!strip) return;
  strip.innerHTML = prayers.map(p => `
    <div class="prayer-pill ${p === currentPrayer ? 'current' : ''}">
      <span class="p-name">${p}</span>
      <span class="p-time">${timings[p]}</span>
    </div>
  `).join('');
}

// Auto-load prayer strip on home page
(async function autoLoadHomeStrip() {
  const strip = document.getElementById('home-prayer-strip');
  if (!strip) return;
  try {
    const today = new Date();
    const url = `https://api.aladhan.com/v1/timingsByCity/${today.getDate()}-${today.getMonth() + 1}-${today.getFullYear()}?city=Karachi&country=Pakistan&method=1`;
    const res = await fetch(url);
    const d = await res.json();
    if (d.code === 200 && d.data?.timings) {
      renderHomePrayerStrip(d.data.timings);
    } else {
      strip.innerHTML = '<div style="color:var(--text-muted);padding:1rem;">Prayer times unavailable</div>';
    }
  } catch (e) {
    console.error('Home prayer strip error:', e);
    strip.innerHTML = '<div style="color:var(--text-muted);padding:1rem;">Prayer times unavailable</div>';
  }
})();
