/* ═══════════════════════════════════════════════════
   NoorApp — Dua, Tasbeeh, Zakat, Qibla, Hadith, Calendar
   ═══════════════════════════════════════════════════ */

// ══════════════════════════════════════════════════════════
// DUA LIBRARY
// ══════════════════════════════════════════════════════════
function renderDua(cat) {
  const cats = document.getElementById('dua-cats');
  if (!cats.children.length) {
    Object.keys(DUA_DATA).forEach(c => {
      const btn = document.createElement('button');
      btn.className = 'dua-cat-btn' + (c === cat ? ' active' : '');
      btn.textContent = {
        morning: '🌅 Morning',
        evening: '🌇 Evening',
        sleep:   '🌙 Sleep',
        food:    '🍽️ Food',
        travel:  '✈️ Travel'
      }[c] || c;
      btn.onclick = () => {
        document.querySelectorAll('.dua-cat-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        renderDua(c);
      };
      cats.appendChild(btn);
    });
  }

  const duas = DUA_DATA[cat] || [];
  document.getElementById('dua-content').innerHTML = duas.map(d => `
    <div class="dua-card">
      <div style="font-weight:600;color:var(--text);margin-bottom:0.8rem;font-size:1.05rem;">${d.name}</div>
      <div class="dua-arabic">${d.ar}</div>
      <div class="dua-transliteration">${d.trl}</div>
      <div class="dua-translation">${d.trans}</div>
    </div>
  `).join('');
}

// ══════════════════════════════════════════════════════════
// TASBEEH COUNTER
// ══════════════════════════════════════════════════════════
function renderTasbeeh() {
  const wrap = document.getElementById('tasbeeh-phrases');
  if (wrap.children.length) return;

  TASBEEH_PHRASES.forEach((p, i) => {
    const btn = document.createElement('button');
    btn.className = 'dua-cat-btn' + (i === 0 ? ' active' : '');
    btn.textContent = p.label;
    btn.onclick = () => {
      document.querySelectorAll('#tasbeeh-phrases .dua-cat-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      activeTasbeehIndex = i;
      tasbeehCount = 0;
      tasbeehSets = 0;
      document.getElementById('tasbeeh-count').textContent = '0';
      document.getElementById('tasbeeh-sets').textContent = '0';
      document.getElementById('tasbeeh-active-label').textContent = p.ar;
      document.getElementById('tasbeeh-full-text').textContent = p.full;
      document.getElementById('tasbeeh-meaning').textContent = p.meaning;
    };
    wrap.appendChild(btn);
  });
}

function incrementTasbeeh(e) {
  // Ripple effect
  const btn = document.getElementById('tasbeeh-btn');
  const ripple = document.createElement('span');
  ripple.className = 'ripple';
  const rect = btn.getBoundingClientRect();
  const size = Math.max(btn.clientWidth, btn.clientHeight);
  ripple.style.width = ripple.style.height = size + 'px';
  ripple.style.left = (e.clientX - rect.left - size / 2) + 'px';
  ripple.style.top = (e.clientY - rect.top - size / 2) + 'px';
  btn.appendChild(ripple);
  setTimeout(() => ripple.remove(), 500);

  tasbeehCount++;
  document.getElementById('tasbeeh-count').textContent = tasbeehCount;

  if (tasbeehCount >= tasbeehTarget) {
    tasbeehSets++;
    tasbeehCount = 0;
    document.getElementById('tasbeeh-count').textContent = '0';
    document.getElementById('tasbeeh-sets').textContent = tasbeehSets;
    btn.style.borderColor = 'var(--green)';
    setTimeout(() => btn.style.borderColor = '', 400);
  }
}

function resetTasbeeh() {
  tasbeehCount = 0;
  tasbeehSets = 0;
  document.getElementById('tasbeeh-count').textContent = '0';
  document.getElementById('tasbeeh-sets').textContent = '0';
}

function changeTarget() {
  tasbeehTarget = parseInt(document.getElementById('target-select').value);
  document.getElementById('tasbeeh-target').textContent = tasbeehTarget;
  resetTasbeeh();
}

// ══════════════════════════════════════════════════════════
// ZAKAT CALCULATOR
// ══════════════════════════════════════════════════════════
const NISAB_PKR = 150000; // Approx. Nisab — silver standard

function calcZakat() {
  const get = id => parseFloat(document.getElementById(id).value) || 0;
  const total =
    get('z-cash') + get('z-gold') + get('z-silver') +
    get('z-business') + get('z-invest') + get('z-debts-in') -
    get('z-debts-out');

  const result = document.getElementById('zakat-result');
  result.classList.add('show');

  if (total < NISAB_PKR) {
    document.getElementById('zakat-amount').textContent = 'PKR 0';
    document.getElementById('zakat-nisab-msg').innerHTML =
      `⚠️ Your total wealth (PKR ${total.toLocaleString()}) is below the Nisab threshold of PKR ${NISAB_PKR.toLocaleString()}. Zakat is not obligatory.`;
    document.getElementById('zakat-amount').style.color = 'var(--text-muted)';
  } else {
    const zakat = total * 0.025;
    document.getElementById('zakat-amount').textContent = 'PKR ' + Math.round(zakat).toLocaleString();
    document.getElementById('zakat-nisab-msg').innerHTML =
      `✅ Net wealth: PKR ${Math.round(total).toLocaleString()} · Nisab: PKR ${NISAB_PKR.toLocaleString()}<br>Zakat = 2.5% of zakatable wealth`;
    document.getElementById('zakat-amount').style.color = 'var(--green)';
  }
}

// ══════════════════════════════════════════════════════════
// QIBLA FINDER
// ══════════════════════════════════════════════════════════
function findQibla() {
  if (!navigator.geolocation) {
    document.getElementById('qibla-info').innerHTML =
      '<div class="error-box">Geolocation not supported in this browser.</div>';
    return;
  }
  document.getElementById('qibla-info').innerHTML = loader();

  navigator.geolocation.getCurrentPosition(
    pos => {
      const lat = pos.coords.latitude;
      const lon = pos.coords.longitude;
      const qibla = calcQiblaDirection(lat, lon);
      document.getElementById('qibla-needle').style.transform = `rotate(${qibla}deg)`;
      document.getElementById('qibla-info').innerHTML = `
        <div class="qibla-degree">${Math.round(qibla)}°</div>
        <div style="color:var(--text-muted);font-size:0.9rem;margin-top:6px;">from North (clockwise)</div>
        <div style="color:var(--text-dim);font-size:0.9rem;margin-top:8px;">📍 Your location: ${lat.toFixed(4)}°N, ${lon.toFixed(4)}°E</div>
        <div style="color:var(--gold);font-family:var(--arabic);font-size:1.4rem;margin-top:12px;direction:rtl;">وَحَيۡثُ مَا كُنتُمۡ فَوَلُّواْ وُجُوهَكُمۡ شَطۡرَهُۥ</div>
        <div style="color:var(--text-muted);font-size:0.85rem;font-style:italic;margin-top:4px;">"Turn your faces toward it" — Quran 2:150</div>
      `;
    },
    () => {
      document.getElementById('qibla-info').innerHTML =
        '<div class="error-box">Could not get location. Please allow location access.</div>';
    }
  );
}

function calcQiblaDirection(lat, lon) {
  const KAABA_LAT = 21.4225;
  const KAABA_LON = 39.8262;
  const φ1 = lat * Math.PI / 180;
  const φ2 = KAABA_LAT * Math.PI / 180;
  const Δλ = (KAABA_LON - lon) * Math.PI / 180;
  const y = Math.sin(Δλ) * Math.cos(φ2);
  const x = Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);
  return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
}

// ══════════════════════════════════════════════════════════
// HADITH (fawazahmed0 CDN)
// ══════════════════════════════════════════════════════════
function setHadithLang(lang) {
  hadithLang = lang;
  document.querySelectorAll('#section-hadith .q-btn').forEach((btn, i) => {
    if (btn.textContent.includes('English') || btn.textContent.includes('اردو')) {
      btn.classList.toggle('active-btn', (lang === 'en' && i === 0) || (lang === 'ur' && i === 1));
    }
  });
  loadHadith();
}

async function loadHadith() {
  const collection = document.getElementById('hadith-collection')?.value || 'bukhari';
  const num = document.getElementById('hadith-num')?.value || '1';
  const el = document.getElementById('hadith-content');
  el.innerHTML = loader();

  try {
    const langCode = hadithLang === 'ur' ? 'urd' : 'eng';
    const url = `https://cdn.jsdelivr.net/gh/fawazahmed0/hadith-api@1/editions/${langCode}-${collection}/${num}.min.json`;
    const res = await fetch(url);
    if (!res.ok) throw new Error('Not found');
    const data = await res.json();
    const hadith = data.hadiths?.[0] || data.hadith?.[0];
    if (!hadith) throw new Error('No hadith data');

    el.innerHTML = `
      <div class="hadith-card">
        <div class="hadith-text">${hadith.text || hadith.body || JSON.stringify(hadith)}</div>
        <div class="hadith-source">📚 ${data.metadata?.name || collection} — Hadith #${num} ${hadith.grades?.length ? '· Grade: ' + hadith.grades[0].grade : ''}</div>
      </div>
      <div style="display:flex;gap:1rem;margin-top:1rem;">
        <button class="q-btn" onclick="navigateHadith(-1)">← Prev</button>
        <button class="q-btn" onclick="navigateHadith(1)">Next →</button>
      </div>
    `;
  } catch (e) {
    console.error('Hadith load error:', e);
    el.innerHTML = getFallbackHadith();
  }
}

function navigateHadith(dir) {
  const inp = document.getElementById('hadith-num');
  inp.value = Math.max(1, (parseInt(inp.value) || 1) + dir);
  loadHadith();
}

function randomHadith() {
  document.getElementById('hadith-num').value = Math.floor(Math.random() * 200) + 1;
  loadHadith();
}

function getFallbackHadith() {
  const h = FALLBACK_HADITHS[Math.floor(Math.random() * FALLBACK_HADITHS.length)];
  const displayText = hadithLang === 'ur' ? h.urdu : h.text;
  return `
    <div class="hadith-card">
      <div class="hadith-text">${displayText}</div>
      <div class="hadith-source">📚 ${h.source}</div>
    </div>
  `;
}

// ══════════════════════════════════════════════════════════
// ISLAMIC CALENDAR (AlAdhan API)
// ══════════════════════════════════════════════════════════
async function loadCalendar() {
  const el = document.getElementById('calendar-content');
  el.innerHTML = loader();

  try {
    const today = new Date();
    const d = today.getDate(), m = today.getMonth() + 1, y = today.getFullYear();
    const res = await fetch(`https://api.aladhan.com/v1/gToH/${d}-${m}-${y}`);
    if (!res.ok) throw new Error('Failed to fetch calendar');
    const data = await res.json();
    if (!data.data?.hijri) throw new Error('Invalid calendar data');

    const hijri = data.data.hijri;
    const greg = data.data.gregorian;

    let html = `
      <div class="hijri-box">
        <div style="font-family:var(--mono);font-size:0.78rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.1em;">Today's Hijri Date</div>
        <div class="hijri-date" style="font-size:2rem;">${hijri.day} ${hijri.month.ar} ${hijri.year}</div>
        <div style="font-family:var(--body);font-size:1rem;color:var(--text-dim);">${hijri.day} ${hijri.month.en} ${hijri.year} AH</div>
        <div class="gregorian-date">${greg.weekday.en}, ${greg.day} ${greg.month.en} ${greg.year} CE</div>
        ${hijri.holidays?.length ? `<div style="color:var(--gold);margin-top:6px;font-size:0.9rem;">🌙 ${hijri.holidays.join(', ')}</div>` : ''}
      </div>

      <div style="margin-bottom:1rem;font-size:1.1rem;color:var(--text-dim);">Upcoming Islamic Events</div>
      <div class="events-list">
    `;

    ISLAMIC_EVENTS.forEach(e => {
      html += `
        <div class="event-item">
          <div class="event-dot"></div>
          <div class="event-name">${e.name}</div>
          <div class="event-date">${e.hijri}<br><span style="color:var(--text-muted);">${e.est}</span></div>
        </div>
      `;
    });
    html += '</div>';

    html += `
      <div style="margin-top:2rem;margin-bottom:1rem;font-size:1.1rem;color:var(--text-dim);">Ramadan Tracker</div>
      <div class="ramadan-grid">
        <div class="r-card"><div class="r-label">Current Hijri Month</div><div class="r-val">${hijri.month.en}</div></div>
        <div class="r-card"><div class="r-label">Hijri Year</div><div class="r-val">${hijri.year} AH</div></div>
        <div class="r-card"><div class="r-label">Days in Month</div><div class="r-val">${hijri.month.days || 30}</div></div>
        <div class="r-card"><div class="r-label">Day of Week</div><div class="r-val">${greg.weekday.en}</div></div>
      </div>
    `;

    el.innerHTML = html;
  } catch (e) {
    console.error('Calendar error:', e);
    el.innerHTML = `<div class="error-box">
      Could not load calendar. Please check your internet connection and try again.
      <br><br>
      <button class="btn-primary" onclick="loadCalendar()">Retry</button>
    </div>`;
  }
}
